package main;

public class EvenNumTest {
	public static boolean isEven(int number)
	{
		if (number%2==0)
		{
			return true;
		}
		return false;
	}

}
